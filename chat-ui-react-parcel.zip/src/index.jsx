import React from "react";
import ReactDOM from "react-dom/client";
import "./styles.css";

function App() {
  return (
    <div className="chat-container">
      <div className="chat-header">Rahul</div>
      <div className="chat-body">
        <div className="message sent">Hello Rahul, how are you?</div>
        <div className="message received">Hi Varakumar, I am good. How about you?</div>
        <div className="message sent">I'm fine. I published my website recently</div>
        <div className="message received">Oh great Varakumar! Can you send me the URL?</div>
        <div className="message sent">https://varakumar.ccbp.tech</div>
        <div className="message received">Awesome Varakumar, where did you learn?</div>
        <div className="message sent">NxtWave CCBP 4.0 Program</div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
